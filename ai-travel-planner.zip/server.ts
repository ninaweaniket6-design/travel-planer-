import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  app.post("/api/generate-itinerary", async (req, res) => {
    try {
      const {
        destination,
        total_days,
        total_people,
        budget,
        interests
      } = req.body;

      if (!process.env.GEMINI_API_KEY) {
        return res.status(500).json({ error: "GEMINI_API_KEY is not set. Please add it to your secrets." });
      }

      const ai = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const prompt = `You are an expert AI Travel Planner and a strict Budget Constraint Solver for a Smart Tourism Platform. 
Your job is to receive user travel parameters and generate a highly optimized, realistic, and personalized travel itinerary in STRICT JSON FORMAT.

Rules for Generation:
1. Budget Engine: Calculate the total budget for the given number of people and days. Deduct estimated costs for accommodation, food, local transport, and tickets. The total expenses MUST NOT exceed the user's budget.
2. Routing: Day-wise itineraries must be geographically logical to minimize travel time and costs. Include distance and route info from the previous place (or hotel if it's the first place of the day).
3. Categories: You must include a mix of "Famous Tourist Places" and "Hidden Gems". Include a star rating and a short review summary for each place.
4. Customization: Tailor the recommendations based on the user's "Interests".
5. Format: DO NOT output markdown, explanations, or conversational text. Output ONLY a valid JSON object matching the requested structure.
6. India Only Constraint: The destination MUST be within India. Include all Indian states and cities as valid options. If the user requests a non-Indian destination, you MUST silently change it to a destination within India that offers a similar experience, and generate the itinerary for that Indian destination instead.
7. Local Food Items: Always include a dedicated array of famous, must-try local food items specific to this destination.
8. Coordinates: Ensure accurate latitude (lat) and longitude (lng) values are provided for every hotel, tourist place, and food destination so they can be plotted on a map.

Travel Parameters:
- Destination: ${destination}
- Total Days: ${total_days}
- Total People: ${total_people}
- Budget: ₹${budget} (Please calculate all costs and budget breakdowns in INR)
- Interests: ${interests}
`;

      const response = await ai.models.generateContent({
        model: "gemini-3.1-flash-lite",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              trip_overview: {
                type: Type.OBJECT,
                properties: {
                  destination: { type: Type.STRING },
                  total_days: { type: Type.NUMBER },
                  total_people: { type: Type.NUMBER },
                  budget_status: { type: Type.STRING, description: "On Budget / Tight / Surplus" }
                },
                required: ["destination", "total_days", "total_people", "budget_status"]
              },
              budget_breakdown: {
                type: Type.OBJECT,
                properties: {
                  accommodation: { type: Type.NUMBER },
                  food: { type: Type.NUMBER },
                  transport: { type: Type.NUMBER },
                  activities: { type: Type.NUMBER },
                  buffer: { type: Type.NUMBER }
                },
                required: ["accommodation", "food", "transport", "activities", "buffer"]
              },
              stay_options: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    type: { type: Type.STRING, description: "Hotel/Dharamshala" },
                    cost_per_night: { type: Type.NUMBER },
                    rating: { type: Type.NUMBER },
                    review_summary: { type: Type.STRING },
                    reason_to_choose: { type: Type.STRING },
                    coordinates: {
                      type: Type.OBJECT,
                      properties: {
                        lat: { type: Type.NUMBER },
                        lng: { type: Type.NUMBER }
                      },
                      required: ["lat", "lng"]
                    }
                  },
                  required: ["name", "type", "cost_per_night", "rating", "review_summary", "reason_to_choose", "coordinates"]
                }
              },
              itinerary: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    day: { type: Type.NUMBER },
                    places: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          time: { type: Type.STRING },
                          name: { type: Type.STRING },
                          type: { type: Type.STRING, description: "Famous / Hidden Gem" },
                          best_visiting_time: { type: Type.STRING },
                          crowd_status: { type: Type.STRING, description: "High / Moderate / Low" },
                          cost: { type: Type.NUMBER },
                          rating: { type: Type.NUMBER },
                          review_summary: { type: Type.STRING },
                          distance_and_route: { type: Type.STRING, description: "E.g., 5km, 15 mins by auto" },
                          coordinates: {
                            type: Type.OBJECT,
                            properties: {
                              lat: { type: Type.NUMBER },
                              lng: { type: Type.NUMBER }
                            },
                            required: ["lat", "lng"]
                          }
                        },
                        required: ["time", "name", "type", "best_visiting_time", "crowd_status", "cost", "rating", "review_summary", "distance_and_route", "coordinates"]
                      }
                    }
                  },
                  required: ["day", "places"]
                }
              },
              food_recommendations: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    restaurant_name: { type: Type.STRING },
                    specialty: { type: Type.STRING },
                    average_cost_for_all: { type: Type.NUMBER },
                    coordinates: {
                      type: Type.OBJECT,
                      properties: {
                        lat: { type: Type.NUMBER },
                        lng: { type: Type.NUMBER }
                      },
                      required: ["lat", "lng"]
                    }
                  },
                  required: ["restaurant_name", "specialty", "average_cost_for_all", "coordinates"]
                }
              },
              famous_local_foods: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    description: { type: Type.STRING }
                  },
                  required: ["name", "description"]
                }
              },
              hotel_recommendations: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    price_range: { type: Type.STRING },
                    location: { type: Type.STRING },
                    coordinates: {
                      type: Type.OBJECT,
                      properties: {
                        lat: { type: Type.NUMBER },
                        lng: { type: Type.NUMBER }
                      },
                      required: ["lat", "lng"]
                    }
                  },
                  required: ["name", "price_range", "location", "coordinates"]
                }
              }
            },
            required: [
              "trip_overview",
              "budget_breakdown",
              "stay_options",
              "itinerary",
              "famous_local_foods",
              "food_recommendations",
              "hotel_recommendations"
            ]
          }
        }
      });

      const text = response.text;
      if (!text) {
          throw new Error("Empty response from AI");
      }
      const data = JSON.parse(text);
      res.json(data);
    } catch (error: any) {
      console.error("Generate error:", error);
      let errorMessage = error.message || "Failed to generate itinerary.";
      try {
        const parsed = JSON.parse(errorMessage);
        if (parsed.error && parsed.error.message) {
          errorMessage = parsed.error.message;
        }
      } catch (e) {
        // Not a JSON string, keep as is
      }
      res.status(500).json({ error: errorMessage });
    }
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
