import { Map, AdvancedMarker, Pin } from '@vis.gl/react-google-maps';
import { useEffect, useState, useRef } from 'react';
import { Search, Navigation, Utensils, Bed, Camera, Landmark, Train, Pill, Banknote } from 'lucide-react';
import type { ItineraryResponse, Coordinates } from './types';

interface TripMapProps {
  result: ItineraryResponse;
}

export function TripMap({ result }: TripMapProps) {
  const [center, setCenter] = useState<Coordinates>({ lat: 28.6139, lng: 77.2090 }); // Default India
  const searchInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Try to find the first valid coordinate to center the map
    if (result.stay_options?.[0]?.coordinates) {
      setCenter(result.stay_options[0].coordinates);
    } else if (result.itinerary?.[0]?.places?.[0]?.coordinates) {
      setCenter(result.itinerary[0].places[0].coordinates);
    }
  }, [result]);

  return (
    <div className="w-full h-full min-h-[400px] rounded-2xl overflow-hidden shadow-sm border border-neutral-200 relative">
      
      {/* Map Overlay Controls */}
      <div className="absolute top-4 left-4 right-4 z-10 flex flex-col md:flex-row items-start md:items-center gap-3 pointer-events-none">
        
        {/* Search Bar */}
        <div className="pointer-events-auto flex items-center bg-white rounded-full shadow-md px-4 py-3 min-w-[320px] max-w-sm w-full transition-shadow hover:shadow-lg">
          <input 
            ref={searchInputRef}
            type="text" 
            placeholder="Search Google Maps" 
            className="flex-1 outline-none text-neutral-800 placeholder:text-neutral-500 bg-transparent text-sm font-medium"
          />
          <div className="flex items-center gap-3 text-neutral-500 border-l border-neutral-200 pl-3 ml-2">
            <Search className="w-5 h-5 cursor-pointer hover:text-neutral-800 transition-colors" />
            <div className="w-8 h-8 bg-[#0a58ca] rounded-full flex items-center justify-center cursor-pointer hover:bg-blue-800 transition-colors">
              <Navigation className="w-4 h-4 text-white rotate-45" />
            </div>
          </div>
        </div>

        {/* Filter Pills Container */}
        <div className="pointer-events-auto flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 w-full mask-fade-right [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          <button className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm hover:shadow-md hover:bg-neutral-50 transition-all border border-neutral-100 flex-shrink-0 text-sm font-medium text-neutral-700">
            <Utensils className="w-4 h-4" /> Restaurants
          </button>
          <button className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm hover:shadow-md hover:bg-neutral-50 transition-all border border-neutral-100 flex-shrink-0 text-sm font-medium text-neutral-700">
            <Bed className="w-4 h-4" /> Hotels
          </button>
          <button className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm hover:shadow-md hover:bg-neutral-50 transition-all border border-neutral-100 flex-shrink-0 text-sm font-medium text-neutral-700">
            <Camera className="w-4 h-4" /> Things to do
          </button>
          <button className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm hover:shadow-md hover:bg-neutral-50 transition-all border border-neutral-100 flex-shrink-0 text-sm font-medium text-neutral-700">
            <Landmark className="w-4 h-4" /> Museums
          </button>
          <button className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm hover:shadow-md hover:bg-neutral-50 transition-all border border-neutral-100 flex-shrink-0 text-sm font-medium text-neutral-700">
            <Train className="w-4 h-4" /> Transit
          </button>
          <button className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm hover:shadow-md hover:bg-neutral-50 transition-all border border-neutral-100 flex-shrink-0 text-sm font-medium text-neutral-700">
            <Pill className="w-4 h-4" /> Pharmacies
          </button>
          <button className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-sm hover:shadow-md hover:bg-neutral-50 transition-all border border-neutral-100 flex-shrink-0 text-sm font-medium text-neutral-700">
            <Banknote className="w-4 h-4" /> ATMs
          </button>
        </div>
      </div>

      <Map
        mapId="DEMO_MAP_ID"
        defaultZoom={11}
        center={center}
        gestureHandling={'greedy'}
        disableDefaultUI={true}
        className="w-full h-full"
        // Source: Google Maps Platform Code Assist
        internalUsageAttributionIds={["gmp_mcp_codeassist_v1_aistudio"]}
      >
        {result.stay_options?.map((stay, idx) => (
          stay.coordinates && (
            <AdvancedMarker key={`stay-${idx}`} position={stay.coordinates}>
              <Pin background="#4f46e5" borderColor="#3730a3" glyphColor="#ffffff" />
            </AdvancedMarker>
          )
        ))}
        {result.itinerary?.flatMap(day => day.places || []).map((place, idx) => (
          place?.coordinates && (
            <AdvancedMarker key={`place-${idx}`} position={place.coordinates}>
              <Pin background="#10b981" borderColor="#047857" glyphColor="#ffffff" />
            </AdvancedMarker>
          )
        ))}
        {result.food_recommendations?.map((food, idx) => (
          food.coordinates && (
            <AdvancedMarker key={`food-${idx}`} position={food.coordinates}>
              <Pin background="#f59e0b" borderColor="#b45309" glyphColor="#ffffff" />
            </AdvancedMarker>
          )
        ))}
      </Map>
    </div>
  );
}
