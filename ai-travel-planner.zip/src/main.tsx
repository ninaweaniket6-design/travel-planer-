import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { APIProvider } from '@vis.gl/react-google-maps';

const MAPS_API_KEY = "AIzaSyCgIRdTiZoimdFkseK2Yb0tPNMuoDX3AR4";

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <APIProvider apiKey={MAPS_API_KEY}>
      <App />
    </APIProvider>
  </StrictMode>,
);
