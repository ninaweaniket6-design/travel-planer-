import React, { useState } from 'react';
import { Plane, Calendar, Users, Wallet, Utensils, MapPin, Map, Loader2, ArrowRight, Hotel, Coffee } from 'lucide-react';
import type { ItineraryResponse } from './types';
import { TripMap } from './TripMap';

export default function App() {
  const [destination, setDestination] = useState('');
  const [totalDays, setTotalDays] = useState(3);
  const [totalPeople, setTotalPeople] = useState(2);
  const [budget, setBudget] = useState(50000);
  const [interests, setInterests] = useState('Religious, Food, History');
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<ItineraryResponse | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const response = await fetch('/api/generate-itinerary', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          destination,
          total_days: totalDays,
          total_people: totalPeople,
          budget,
          interests: interests,
        }),
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate itinerary');
      }
      
      setResult(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900 font-sans selection:bg-indigo-100 selection:text-indigo-900">
      <header className="bg-white border-b border-neutral-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 text-indigo-600">
            <Plane className="w-6 h-6" />
            <span className="font-semibold text-lg tracking-tight">AI Travel Planner</span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          
          {/* Sidebar / Form */}
          <div className="lg:col-span-4">
            <div className="bg-white rounded-2xl shadow-sm border border-neutral-200 p-6 sticky top-24">
              <h2 className="text-xl font-medium mb-6">Plan Your Trip</h2>
              
              <form onSubmit={handleGenerate} className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1.5 flex items-center gap-1.5">
                    <MapPin className="w-4 h-4" /> Destination (India)
                  </label>
                  <input
                    type="text"
                    required
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    placeholder="e.g. Jaipur, Rajasthan"
                    className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none transition-all"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-neutral-700 mb-1.5 flex items-center gap-1.5">
                      <Calendar className="w-4 h-4" /> Days
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="30"
                      required
                      value={totalDays}
                      onChange={(e) => setTotalDays(parseInt(e.target.value))}
                      className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-neutral-700 mb-1.5 flex items-center gap-1.5">
                      <Users className="w-4 h-4" /> People
                    </label>
                    <input
                      type="number"
                      min="1"
                      max="20"
                      required
                      value={totalPeople}
                      onChange={(e) => setTotalPeople(parseInt(e.target.value))}
                      className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none transition-all"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1.5 flex items-center gap-1.5">
                    <Wallet className="w-4 h-4" /> Total Budget (INR)
                  </label>
                  <input
                    type="number"
                    min="10"
                    required
                    value={budget}
                    onChange={(e) => setBudget(parseInt(e.target.value))}
                    className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none transition-all"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-neutral-700 mb-1.5 flex items-center gap-1.5">
                    <Map className="w-4 h-4" /> Interests
                  </label>
                  <input
                    type="text"
                    required
                    value={interests}
                    onChange={(e) => setInterests(e.target.value)}
                    placeholder="e.g. Religious, Food, History"
                    className="w-full px-4 py-2.5 rounded-xl border border-neutral-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none transition-all"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full mt-4 flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white py-3 px-4 rounded-xl font-medium transition-colors disabled:opacity-70 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Generating Itinerary...
                    </>
                  ) : (
                    <>
                      Generate Itinerary <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>

              {error && (
                <div className="mt-4 p-4 bg-red-50 text-red-700 rounded-xl text-sm border border-red-100">
                  {error}
                </div>
              )}
            </div>
          </div>

          {/* Results Area */}
          <div className="lg:col-span-8">
            {loading ? (
              <div className="h-full min-h-[400px] flex flex-col items-center justify-center text-neutral-400 space-y-4 bg-white rounded-2xl border border-neutral-200 shadow-sm border-dashed">
                <Loader2 className="w-8 h-8 animate-spin text-indigo-400" />
                <p>Crafting your perfect journey...</p>
              </div>
            ) : result ? (
              <div className="space-y-8">
                
                {/* Overview Header */}
                <div className="bg-white rounded-2xl p-8 shadow-sm border border-neutral-200">
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                    <div>
                      <h1 className="text-3xl font-bold tracking-tight mb-2">Trip to {result.trip_overview.destination}</h1>
                      <div className="flex flex-wrap items-center gap-3 text-neutral-600">
                        <span className="flex items-center gap-1.5 bg-neutral-100 px-3 py-1 rounded-full text-sm font-medium">
                          <Calendar className="w-4 h-4" /> {result.trip_overview.total_days} Days
                        </span>
                        <span className="flex items-center gap-1.5 bg-neutral-100 px-3 py-1 rounded-full text-sm font-medium">
                          <Users className="w-4 h-4" /> {result.trip_overview.total_people} People
                        </span>
                        <span className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-sm font-medium ${
                          result.trip_overview.budget_status === 'Surplus' ? 'bg-emerald-100 text-emerald-800' : 
                          result.trip_overview.budget_status === 'Tight' ? 'bg-amber-100 text-amber-800' : 
                          'bg-indigo-100 text-indigo-800'
                        }`}>
                          <Wallet className="w-4 h-4" /> Budget: {result.trip_overview.budget_status}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Interactive Map */}
                <div className="bg-white rounded-2xl p-4 shadow-sm border border-neutral-200 h-[500px]">
                  <TripMap result={result} />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Budget Breakdown */}
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-neutral-200">
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                      <Wallet className="w-5 h-5 text-indigo-500" /> Budget Breakdown
                    </h3>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center py-2 border-b border-neutral-100">
                        <span className="text-neutral-600">Accommodation</span>
                        <span className="font-medium">₹{result.budget_breakdown.accommodation}</span>
                      </div>
                      <div className="flex justify-between items-center py-2 border-b border-neutral-100">
                        <span className="text-neutral-600">Food</span>
                        <span className="font-medium">₹{result.budget_breakdown.food}</span>
                      </div>
                      <div className="flex justify-between items-center py-2 border-b border-neutral-100">
                        <span className="text-neutral-600">Transport</span>
                        <span className="font-medium">₹{result.budget_breakdown.transport}</span>
                      </div>
                      <div className="flex justify-between items-center py-2 border-b border-neutral-100">
                        <span className="text-neutral-600">Activities</span>
                        <span className="font-medium">₹{result.budget_breakdown.activities}</span>
                      </div>
                      <div className="flex justify-between items-center py-2 text-amber-600">
                        <span>Buffer</span>
                        <span className="font-medium">₹{result.budget_breakdown.buffer}</span>
                      </div>
                      <div className="flex justify-between items-center pt-3 mt-1 border-t-2 border-neutral-100 font-semibold text-lg">
                        <span>Total Estimated</span>
                        <span>
                          ₹{
                            result.budget_breakdown.accommodation +
                            result.budget_breakdown.food +
                            result.budget_breakdown.transport +
                            result.budget_breakdown.activities +
                            result.budget_breakdown.buffer
                          }
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Accommodation Options */}
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-neutral-200">
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                      <Hotel className="w-5 h-5 text-indigo-500" /> Stay Options
                    </h3>
                    <div className="space-y-4">
                      {result.stay_options.map((stay, idx) => (
                        <div key={idx} className="p-4 rounded-xl border border-neutral-100 bg-neutral-50/50">
                          <div className="flex justify-between items-start mb-2">
                            <div>
                              <div className="flex items-center gap-2">
                                <h4 className="font-medium text-neutral-900">{stay.name}</h4>
                                <a
                                  href={stay.coordinates ? `https://www.google.com/maps/search/?api=1&query=${stay.coordinates.lat},${stay.coordinates.lng}` : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(stay.name + ' ' + destination)}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center justify-center text-indigo-500 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 p-1 rounded-full transition-colors"
                                  title="View on Google Maps"
                                >
                                  <MapPin className="w-3.5 h-3.5" />
                                </a>
                              </div>
                              <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-white border border-neutral-200 text-neutral-500 mt-1 inline-block">
                                {stay.type}
                              </span>
                            </div>
                            <div className="text-right">
                              <div className="font-semibold text-indigo-600">₹{stay.cost_per_night}<span className="text-xs font-normal text-neutral-500">/night</span></div>
                              <div className="text-sm font-medium text-emerald-600">★ {stay.rating}</div>
                            </div>
                          </div>
                          <p className="text-sm text-neutral-600 mt-2">{stay.reason_to_choose}</p>
                          {stay.review_summary && (
                            <div className="mt-2 text-xs italic text-neutral-500 border-t border-neutral-200 pt-2">"{stay.review_summary}"</div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Day by Day Itinerary */}
                <div className="bg-white rounded-2xl p-6 shadow-sm border border-neutral-200">
                  <h3 className="text-xl font-semibold mb-6 flex items-center gap-2">
                    <Map className="w-6 h-6 text-indigo-500" /> Day-by-Day Itinerary
                  </h3>
                  
                  <div className="space-y-8">
                    {result.itinerary.map((day, dIdx) => (
                      <div key={dIdx} className="relative">
                        <div className="flex items-center gap-4 mb-4">
                          <div className="bg-indigo-600 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold shadow-md z-10 ring-4 ring-white">
                            {day.day}
                          </div>
                          <h4 className="text-lg font-bold">Day {day.day}</h4>
                        </div>
                        
                        <div className="pl-5 ml-0 border-l-2 border-indigo-100 space-y-6 pb-2">
                          {(day.places || []).map((place, pIdx) => (
                            <div key={pIdx} className="relative pl-6">
                              {/* Connector dot */}
                              <div className="absolute w-3 h-3 bg-indigo-400 rounded-full -left-[7.5px] top-1.5 ring-4 ring-white" />
                              
                              <div className="bg-neutral-50 border border-neutral-100 rounded-xl p-4 transition-all hover:shadow-md hover:border-indigo-100">
                                <div className="flex justify-between items-start flex-wrap gap-2 mb-2">
                                  <div>
                                    <span className="text-sm font-semibold text-indigo-600 tracking-wider mb-1 block">
                                      {place.time}
                                    </span>
                                    <div className="flex items-center gap-2 mt-0.5">
                                      <h5 className="font-bold text-lg text-neutral-900 leading-tight">{place.name}</h5>
                                      <a
                                        href={place.coordinates ? `https://www.google.com/maps/search/?api=1&query=${place.coordinates.lat},${place.coordinates.lng}` : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(place.name + ' ' + destination)}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="inline-flex items-center justify-center text-indigo-500 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 p-1.5 rounded-full transition-colors"
                                        title="View on Google Maps"
                                      >
                                        <MapPin className="w-3.5 h-3.5" />
                                      </a>
                                    </div>
                                    {place.distance_and_route && (
                                      <p className="text-xs text-neutral-500 mt-1 flex items-center gap-1">
                                        <MapPin className="w-3 h-3" /> {place.distance_and_route}
                                      </p>
                                    )}
                                  </div>
                                  <div className="text-right">
                                    <span className="font-semibold text-neutral-800">₹{place.cost}</span>
                                    {place.rating && (
                                      <div className="text-sm font-medium text-emerald-600 mt-1">★ {place.rating}</div>
                                    )}
                                  </div>
                                </div>
                                
                                {place.review_summary && (
                                  <p className="text-sm text-neutral-600 italic mb-3">"{place.review_summary}"</p>
                                )}
                                
                                <div className="flex flex-wrap gap-2 mt-3">
                                  <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${
                                    place.type.toLowerCase().includes('hidden') ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
                                  }`}>
                                    {place.type}
                                  </span>
                                  <span className="text-xs px-2.5 py-1 rounded-full bg-neutral-200/60 text-neutral-700 font-medium flex items-center gap-1">
                                    Best time: {place.best_visiting_time}
                                  </span>
                                  <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${
                                    place.crowd_status.toLowerCase().includes('high') ? 'bg-rose-100 text-rose-700' :
                                    place.crowd_status.toLowerCase().includes('moderate') ? 'bg-amber-100 text-amber-700' :
                                    'bg-emerald-100 text-emerald-700'
                                  }`}>
                                    Crowd: {place.crowd_status}
                                  </span>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Famous Local Foods */}
                {result.famous_local_foods && result.famous_local_foods.length > 0 && (
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-neutral-200">
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                      <Utensils className="w-5 h-5 text-indigo-500" /> Famous Must-Try Foods
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                      {result.famous_local_foods.map((food, idx) => (
                        <div key={idx} className="p-4 rounded-xl border border-neutral-100 bg-orange-50/50 hover:border-orange-200 transition-colors">
                          <h4 className="font-semibold text-orange-900 mb-1">{food.name}</h4>
                          <p className="text-sm text-neutral-700">{food.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Food Recommendations */}
                <div className="bg-white rounded-2xl p-6 shadow-sm border border-neutral-200">
                  <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                    <Coffee className="w-5 h-5 text-indigo-500" /> Food & Dining
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                    {result.food_recommendations.map((food, idx) => (
                      <div key={idx} className="p-4 rounded-xl border border-neutral-100 bg-neutral-50 hover:border-indigo-200 transition-colors">
                        <div className="flex items-center justify-between gap-2">
                          <h4 className="font-semibold text-neutral-900 truncate">{food.restaurant_name}</h4>
                          <a
                            href={food.coordinates ? `https://www.google.com/maps/search/?api=1&query=${food.coordinates.lat},${food.coordinates.lng}` : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(food.restaurant_name + ' ' + destination)}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center justify-center text-indigo-500 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 p-1 rounded-full transition-colors flex-shrink-0"
                            title="View on Google Maps"
                          >
                            <MapPin className="w-3.5 h-3.5" />
                          </a>
                        </div>
                        <p className="text-sm text-neutral-600 mt-1 line-clamp-2 min-h-[40px]">{food.specialty}</p>
                        <div className="mt-3 pt-3 border-t border-neutral-200 flex justify-between items-center">
                          <span className="text-xs text-neutral-500 font-medium uppercase tracking-wider">Avg Cost</span>
                          <span className="font-semibold text-neutral-900">₹{food.average_cost_for_all}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Additional Hotel Recommendations */}
                {result.hotel_recommendations && result.hotel_recommendations.length > 0 && (
                  <div className="bg-white rounded-2xl p-6 shadow-sm border border-neutral-200">
                    <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                      <Hotel className="w-5 h-5 text-indigo-500" /> Area Hotels
                    </h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                      {result.hotel_recommendations.map((hotel, idx) => (
                        <div key={idx} className="p-4 rounded-xl border border-neutral-100 bg-neutral-50 hover:border-indigo-200 transition-colors flex flex-col justify-between">
                          <div>
                            <div className="flex items-center justify-between gap-2">
                              <h4 className="font-semibold text-neutral-900 truncate">{hotel.name}</h4>
                              <a
                                href={hotel.coordinates ? `https://www.google.com/maps/search/?api=1&query=${hotel.coordinates.lat},${hotel.coordinates.lng}` : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(hotel.name + ' ' + destination)}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center justify-center text-indigo-500 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 p-1 rounded-full transition-colors flex-shrink-0"
                                title="View on Google Maps"
                              >
                                <MapPin className="w-3.5 h-3.5" />
                              </a>
                            </div>
                            <p className="text-sm text-neutral-600 mt-1 flex items-center gap-1 line-clamp-2"><MapPin className="w-3 h-3 flex-shrink-0" /> {hotel.location || 'Location details unavailable'}</p>
                          </div>
                          <div className="mt-3 pt-3 border-t border-neutral-200 flex justify-between items-center">
                            <span className="text-xs text-neutral-500 font-medium uppercase tracking-wider">Budget Tier</span>
                            <span className="text-sm font-medium text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-100 whitespace-nowrap">{hotel.price_range}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
              </div>
            ) : (
              <div className="h-full min-h-[400px] flex flex-col items-center justify-center text-neutral-400 bg-white rounded-2xl border border-neutral-200 shadow-sm border-dashed p-8 text-center">
                <Map className="w-12 h-12 text-neutral-300 mb-4" />
                <h3 className="text-lg font-medium text-neutral-900 mb-1">No Itinerary Yet</h3>
                <p className="max-w-sm">Enter your travel details and preferences on the left to generate a personalized itinerary.</p>
              </div>
            )}
          </div>

        </div>
      </main>
    </div>
  );
}

