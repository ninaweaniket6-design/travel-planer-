export interface TripOverview {
  destination: string;
  total_days: number;
  total_people: number;
  budget_status: string;
}

export interface BudgetBreakdown {
  accommodation: number;
  food: number;
  transport: number;
  activities: number;
  buffer: number;
}

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface StayOption {
  name: string;
  type: string;
  cost_per_night: number;
  rating: number;
  review_summary: string;
  reason_to_choose: string;
  coordinates: Coordinates;
}

export interface Place {
  time: string;
  name: string;
  type: string;
  best_visiting_time: string;
  crowd_status: string;
  cost: number;
  rating: number;
  review_summary: string;
  distance_and_route: string;
  coordinates: Coordinates;
}

export interface DayItinerary {
  day: number;
  places: Place[];
}

export interface FoodRecommendation {
  restaurant_name: string;
  specialty: string;
  average_cost_for_all: number;
  coordinates: Coordinates;
}

export interface HotelRecommendation {
  name: string;
  price_range: string;
  location: string;
  coordinates: Coordinates;
}

export interface FamousFood {
  name: string;
  description: string;
}

export interface ItineraryResponse {
  trip_overview: TripOverview;
  budget_breakdown: BudgetBreakdown;
  stay_options: StayOption[];
  itinerary: DayItinerary[];
  famous_local_foods: FamousFood[];
  food_recommendations: FoodRecommendation[];
  hotel_recommendations: HotelRecommendation[];
}
